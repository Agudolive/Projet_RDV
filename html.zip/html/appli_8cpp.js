var appli_8cpp =
[
    [ "wxIMPLEMENT_APP", "appli_8cpp.html#a1ccd41a3ba58310313324ca139806f3f", null ]
];