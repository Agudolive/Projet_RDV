var searchData=
[
  ['parse_5fevent_5ft',['parse_event_t',['../classnlohmann_1_1basic__json.html#aea1c863b719b4ca5b77188c171bbfafe',1,'nlohmann::basic_json']]]
];
