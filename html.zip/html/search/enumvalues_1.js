var searchData=
[
  ['boolean',['boolean',['../namespacenlohmann_1_1detail.html#a90aa5ef615aa8305e9ea20d8a947980fa84e2c64f38f78ba3ea5c905ab5a2da27',1,'nlohmann::detail']]]
];
