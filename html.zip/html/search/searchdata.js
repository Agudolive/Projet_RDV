var indexSectionsWithContent =
{
  0: "abcdefghijklmnoprstuv~",
  1: "abcefhijlnpst",
  2: "n",
  3: "abcdefgijklmoprstuv~",
  4: "abcdijnoprsv",
  5: "pv",
  6: "abdknosv",
  7: "bo"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "typedefs",
  5: "enums",
  6: "enumvalues",
  7: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Typedefs",
  5: "Enumerations",
  6: "Enumerator",
  7: "Friends"
};

