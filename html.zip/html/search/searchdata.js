var indexSectionsWithContent =
{
  0: "acefgjlmosw~",
  1: "acfl",
  2: "acfl",
  3: "acefglmosw~",
  4: "j",
  5: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "typedefs",
  5: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Typedefs",
  5: "Friends"
};

