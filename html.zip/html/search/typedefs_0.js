var searchData=
[
  ['allocator_5ftype',['allocator_type',['../classnlohmann_1_1basic__json.html#a86ce930490cf7773b26f5ef49c04a350',1,'nlohmann::basic_json']]],
  ['array_5ft',['array_t',['../classnlohmann_1_1basic__json.html#a4c409f1b6d9caf3412c78af9a5883fed',1,'nlohmann::basic_json']]]
];
