var searchData=
[
  ['base_5fiterator',['base_iterator',['../classnlohmann_1_1basic__json_1_1json__reverse__iterator.html#a5b7f3c5d86fe89a65d9552c1cac37261',1,'nlohmann::basic_json::json_reverse_iterator']]],
  ['boolean_5ft',['boolean_t',['../classnlohmann_1_1basic__json.html#a4c919102a9b4fe0d588af64801436082',1,'nlohmann::basic_json']]]
];
