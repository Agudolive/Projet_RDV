var searchData=
[
  ['iterator',['iterator',['../classnlohmann_1_1basic__json.html#a099316232c76c034030a38faa6e34dca',1,'nlohmann::basic_json']]],
  ['iterator_5fcategory',['iterator_category',['../classnlohmann_1_1basic__json_1_1iter__impl.html#adbe1b700b9cdc38f6991fc68683a9c2c',1,'nlohmann::basic_json::iter_impl']]]
];
