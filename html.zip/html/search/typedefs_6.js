var searchData=
[
  ['number_5ffloat_5ft',['number_float_t',['../classnlohmann_1_1basic__json.html#a88d6103cb3620410b35200ee8e313d97',1,'nlohmann::basic_json']]],
  ['number_5finteger_5ft',['number_integer_t',['../classnlohmann_1_1basic__json.html#a98e611d67b7bd75307de99c9358ab2dc',1,'nlohmann::basic_json']]],
  ['number_5funsigned_5ft',['number_unsigned_t',['../classnlohmann_1_1basic__json.html#ab906e29b5d83ac162e823ada2156b989',1,'nlohmann::basic_json']]]
];
